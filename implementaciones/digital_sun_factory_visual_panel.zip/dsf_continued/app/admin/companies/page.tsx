import { AdminCompanyForm } from '@/components/admin-company-form'
import { CompanySelector } from '@/components/company-selector'
import { getCompanyOverview, listCompanies } from '@/lib/dashboard'

export default async function AdminCompaniesPage({ searchParams }: { searchParams?: Promise<{ companyId?: string }> }) {
  const params = await searchParams
  const companies = await listCompanies()
  const currentId = params?.companyId || companies[0]?.id
  const overview = await getCompanyOverview(currentId)

  return (
    <main className="container page-stack">
      <section className="hero compact">
        <span className="eyebrow">Admin general</span>
        <h1>Multiempresa lista para vender</h1>
        <p className="muted max-720">Creá nuevas empresas, asigná owners y validá en minutos el estado comercial y operativo del tenant.</p>
      </section>

      <div className="row between wrap gap-16">
        <CompanySelector companies={companies} currentId={currentId} path="/admin/companies" />
        <a className="button ghost" href="/portal">Abrir portal de empresa</a>
      </div>

      <section className="grid grid-4">
        <article className="card stat"><span className="muted small">Empresa activa</span><strong>{overview.company.name}</strong></article>
        <article className="card stat"><span className="muted small">Agentes</span><strong>{overview.agentsCount}</strong></article>
        <article className="card stat"><span className="muted small">Automatizaciones</span><strong>{overview.workflowsCount}</strong></article>
        <article className="card stat"><span className="muted small">WhatsApp</span><strong>{overview.whatsappConnected ? 'Conectado' : 'Pendiente'}</strong></article>
      </section>

      <div className="grid grid-2">
        <AdminCompanyForm />
        <section className="card">
          <h3>Últimos mensajes</h3>
          <div className="conversation-list">
            {overview.latestMessages.map((message) => (
              <article key={message.id} className={`message-row ${message.direction === 'out' ? 'out' : 'in'}`}>
                <div>
                  <strong>{message.direction === 'out' ? 'Agente' : message.contact_handle}</strong>
                  <p>{message.content}</p>
                </div>
                <span className="small muted">{new Date(message.created_at).toLocaleString('es-AR')}</span>
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
