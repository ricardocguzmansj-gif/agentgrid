import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getSupabaseAdmin } from '@/lib/supabase'

const schema = z.object({
  companyId: z.string().uuid(),
  name: z.string().min(2),
  niche: z.enum(['general', 'ecommerce', 'clinic', 'real_estate', 'education']),
  systemPrompt: z.string().min(10)
})

export async function GET(request: NextRequest) {
  try {
    const companyId = new URL(request.url).searchParams.get('companyId')
    if (!companyId) return NextResponse.json({ error: 'Missing companyId' }, { status: 400 })
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('ai_agents').select('*').eq('company_id', companyId).order('created_at', { ascending: false })
    if (error) throw error
    return NextResponse.json({ ok: true, agents: data ?? [] })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = schema.parse(await request.json())
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('ai_agents').insert({
      company_id: body.companyId,
      name: body.name,
      niche: body.niche,
      system_prompt: body.systemPrompt,
      is_active: true
    }).select('*').single()
    if (error) throw error
    return NextResponse.json({ ok: true, agent: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}
