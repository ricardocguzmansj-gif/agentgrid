import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getSupabaseAdmin } from '@/lib/supabase'

const schema = z.object({
  companyId: z.string().uuid(),
  metaPhoneNumberId: z.string().min(3),
  metaAccessToken: z.string().min(10),
  phoneDisplay: z.string().optional()
})

export async function GET(request: NextRequest) {
  try {
    const companyId = new URL(request.url).searchParams.get('companyId')
    if (!companyId) return NextResponse.json({ error: 'Missing companyId' }, { status: 400 })
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('whatsapp_channels').select('*').eq('company_id', companyId).order('created_at', { ascending: false })
    if (error) throw error
    return NextResponse.json({ ok: true, channels: data ?? [] })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = schema.parse(await request.json())
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('whatsapp_channels').upsert({
      company_id: body.companyId,
      meta_phone_number_id: body.metaPhoneNumberId,
      meta_access_token: body.metaAccessToken,
      phone_display: body.phoneDisplay || null,
      is_active: true
    }, { onConflict: 'meta_phone_number_id' }).select('*').single()
    if (error) throw error
    return NextResponse.json({ ok: true, channel: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}
