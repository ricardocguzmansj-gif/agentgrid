import { NextRequest, NextResponse } from 'next/server'
import { getSupabaseAdmin } from '@/lib/supabase'

export async function GET(request: NextRequest) {
  try {
    const companyId = new URL(request.url).searchParams.get('companyId')
    if (!companyId) return NextResponse.json({ error: 'Missing companyId' }, { status: 400 })
    const supabase = getSupabaseAdmin()
    const [inbound, outbound] = await Promise.all([
      supabase.from('inbound_messages').select('id, contact_handle, content, created_at').eq('company_id', companyId).order('created_at', { ascending: false }).limit(20),
      supabase.from('outbound_messages').select('id, contact_handle, content, created_at').eq('company_id', companyId).order('created_at', { ascending: false }).limit(20)
    ])
    return NextResponse.json({
      ok: true,
      messages: [
        ...((inbound.data ?? []).map((m:any) => ({ ...m, direction: 'in' }))),
        ...((outbound.data ?? []).map((m:any) => ({ ...m, direction: 'out' })))
      ].sort((a,b)=> +new Date(b.created_at) - +new Date(a.created_at))
    })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}
