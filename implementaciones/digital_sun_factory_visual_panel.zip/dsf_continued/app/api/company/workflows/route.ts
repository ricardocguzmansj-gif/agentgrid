import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getSupabaseAdmin } from '@/lib/supabase'

const schema = z.object({
  companyId: z.string().uuid(),
  name: z.string().min(2),
  channelType: z.enum(['email', 'whatsapp']),
  promptTemplate: z.string().min(10),
  cronSchedule: z.string().min(5),
  targetContact: z.string().optional()
})

export async function GET(request: NextRequest) {
  try {
    const companyId = new URL(request.url).searchParams.get('companyId')
    if (!companyId) return NextResponse.json({ error: 'Missing companyId' }, { status: 400 })
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('automation_workflows').select('*').eq('company_id', companyId).order('created_at', { ascending: false })
    if (error) throw error
    return NextResponse.json({ ok: true, workflows: data ?? [] })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = schema.parse(await request.json())
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('automation_workflows').insert({
      company_id: body.companyId,
      name: body.name,
      channel_type: body.channelType,
      prompt_template: body.promptTemplate,
      cron_schedule: body.cronSchedule,
      target_contact: body.targetContact || null,
      is_active: true
    }).select('*').single()
    if (error) throw error
    return NextResponse.json({ ok: true, workflow: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}
