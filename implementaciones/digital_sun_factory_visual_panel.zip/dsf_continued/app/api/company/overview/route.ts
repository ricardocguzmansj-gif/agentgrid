import { NextRequest, NextResponse } from 'next/server'
import { getCompanyOverview } from '@/lib/dashboard'

export async function GET(request: NextRequest) {
  try {
    const companyId = new URL(request.url).searchParams.get('companyId') || undefined
    const overview = await getCompanyOverview(companyId)
    return NextResponse.json({ ok: true, overview })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 400 })
  }
}
