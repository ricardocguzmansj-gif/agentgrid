export default function HomePage() {
  return (
    <main className="container page-stack">
      <section className="hero">
        <span className="eyebrow">Digital Sun SaaS Factory</span>
        <h1>Panel comercial multiempresa con IA real, WhatsApp y automatizaciones</h1>
        <p className="muted max-720">Este entorno ya incluye creación de empresas, webhook inbound de WhatsApp, respuestas con OpenAI, workflows por cron y un portal visual listo para demo o despliegue.</p>
        <div className="row wrap gap-16">
          <a className="button" href="/admin/companies">Entrar al admin general</a>
          <a className="button ghost" href="/portal">Abrir portal de empresa</a>
        </div>
      </section>

      <section className="grid grid-3">
        <article className="card">
          <h3>Admin general</h3>
          <p className="muted">Crea tenants, asigna owners y supervisa estado operativo.</p>
        </article>
        <article className="card">
          <h3>Portal por empresa</h3>
          <p className="muted">Gestiona agentes, canales de WhatsApp, workflows y conversaciones.</p>
        </article>
        <article className="card">
          <h3>Automatización completa</h3>
          <p className="muted">Cloudflare Cron dispara tareas y OpenAI genera respuestas reales.</p>
        </article>
      </section>
    </main>
  )
}
