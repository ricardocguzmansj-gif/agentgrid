import { AgentForm } from '@/components/agent-form'
import { AiPlayground } from '@/components/ai-playground'
import { CompanySelector } from '@/components/company-selector'
import { WhatsAppChannelForm } from '@/components/whatsapp-channel-form'
import { WorkflowForm } from '@/components/workflow-form'
import { getCompanyOverview, listAgents, listCompanies, listWorkflows } from '@/lib/dashboard'

export default async function PortalPage({ searchParams }: { searchParams?: Promise<{ companyId?: string }> }) {
  const params = await searchParams
  const companies = await listCompanies()
  const currentId = params?.companyId || companies[0]?.id
  const overview = await getCompanyOverview(currentId)
  const [agents, workflows] = currentId ? await Promise.all([listAgents(currentId), listWorkflows(currentId)]) : [[], []]

  return (
    <main className="container page-stack">
      <section className="hero compact branded" style={{ ['--brand' as any]: overview.company.brand_primary || '#58a6ff' }}>
        <span className="eyebrow">Portal por empresa</span>
        <h1>{overview.company.name}</h1>
        <p className="muted max-720">Gestioná agentes, canales, conversaciones y automatizaciones desde una sola vista operativa.</p>
      </section>

      <div className="row between wrap gap-16">
        <CompanySelector companies={companies} currentId={currentId} path="/portal" />
        <a className="button ghost" href="/admin/companies">Volver al admin</a>
      </div>

      <section className="grid grid-4">
        <article className="card stat"><span className="muted small">Mensajes 24h</span><strong>{overview.messages24h}</strong></article>
        <article className="card stat"><span className="muted small">Agentes activos</span><strong>{overview.activeAgents}</strong></article>
        <article className="card stat"><span className="muted small">Workflows</span><strong>{overview.workflowsCount}</strong></article>
        <article className="card stat"><span className="muted small">Canal</span><strong>{overview.whatsappConnected ? 'WhatsApp OK' : 'Sin conectar'}</strong></article>
      </section>

      <div className="grid grid-2 top">
        <AgentForm companyId={overview.company.id} companyName={overview.company.name} />
        <WhatsAppChannelForm companyId={overview.company.id} />
        <WorkflowForm companyId={overview.company.id} />
        <AiPlayground companyName={overview.company.name} />
      </div>

      <div className="grid grid-2 top">
        <section className="card">
          <h3>Agentes cargados</h3>
          <div className="stack-12">
            {agents.length ? agents.map((agent) => (
              <article key={agent.id} className="list-item">
                <div>
                  <strong>{agent.name}</strong>
                  <p className="small muted">{agent.niche} · {agent.is_active ? 'Activo' : 'Inactivo'}</p>
                </div>
                <span className="pill">IA</span>
              </article>
            )) : <p className="muted">Todavía no hay agentes guardados.</p>}
          </div>
        </section>

        <section className="card">
          <h3>Automatizaciones</h3>
          <div className="stack-12">
            {workflows.length ? workflows.map((workflow) => (
              <article key={workflow.id} className="list-item">
                <div>
                  <strong>{workflow.name}</strong>
                  <p className="small muted">{workflow.channel} · {workflow.cron_schedule}</p>
                </div>
                <span className="pill">{workflow.is_active ? 'Activa' : 'Pausada'}</span>
              </article>
            )) : <p className="muted">Todavía no hay workflows cargados.</p>}
          </div>
        </section>
      </div>

      <section className="card">
        <h3>Conversaciones recientes</h3>
        <div className="conversation-list">
          {overview.latestMessages.map((message) => (
            <article key={message.id} className={`message-row ${message.direction === 'out' ? 'out' : 'in'}`}>
              <div>
                <strong>{message.direction === 'out' ? 'Agente' : message.contact_handle}</strong>
                <p>{message.content}</p>
              </div>
              <span className="small muted">{new Date(message.created_at).toLocaleString('es-AR')}</span>
            </article>
          ))}
        </div>
      </section>
    </main>
  )
}
