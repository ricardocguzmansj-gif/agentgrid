'use client'

import { useState } from 'react'

export function WhatsAppChannelForm({ companyId }: { companyId: string }) {
  const [metaPhoneNumberId, setMetaPhoneNumberId] = useState('')
  const [metaAccessToken, setMetaAccessToken] = useState('')
  const [phoneDisplay, setPhoneDisplay] = useState('')
  const [status, setStatus] = useState('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('Guardando...')
    const res = await fetch('/api/company/whatsapp-channel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyId, metaPhoneNumberId, metaAccessToken, phoneDisplay })
    })
    const data = await res.json()
    setStatus(res.ok ? 'Canal guardado correctamente' : data.error || 'Error')
  }

  return (
    <form onSubmit={submit} className="card">
      <h3>Canal de WhatsApp</h3>
      <div className="grid grid-2">
        <label>Meta phone_number_id<input value={metaPhoneNumberId} onChange={(e)=>setMetaPhoneNumberId(e.target.value)} required /></label>
        <label>Nombre visible / teléfono<input value={phoneDisplay} onChange={(e)=>setPhoneDisplay(e.target.value)} /></label>
        <label className="span-2">Meta access token<textarea rows={4} value={metaAccessToken} onChange={(e)=>setMetaAccessToken(e.target.value)} required /></label>
      </div>
      <div className="row between center">
        <span className="small muted">Después apuntá Meta al webhook /api/webhooks/whatsapp.</span>
        <button className="button">Guardar canal</button>
      </div>
      {status ? <p className="small">{status}</p> : null}
    </form>
  )
}
