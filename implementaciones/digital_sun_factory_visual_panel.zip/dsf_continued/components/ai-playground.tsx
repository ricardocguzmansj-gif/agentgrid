'use client'

import { useState } from 'react'

export function AiPlayground({ companyName }: { companyName: string }) {
  const [system, setSystem] = useState(`You are the sales copilot for ${companyName}.`)
  const [user, setUser] = useState('Quiero saber cómo instalar el sistema en mi empresa.')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  async function run(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setResult('')
    try {
      const res = await fetch('/api/ai/reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ system, user })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'No se pudo generar')
      setResult(data.text)
    } catch (err) {
      setResult(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={run} className="card">
      <h3>Playground IA</h3>
      <div className="grid">
        <label>System prompt<textarea rows={4} value={system} onChange={(e)=>setSystem(e.target.value)} /></label>
        <label>Mensaje del usuario<textarea rows={4} value={user} onChange={(e)=>setUser(e.target.value)} /></label>
      </div>
      <div className="row between center">
        <span className="small muted">Usa OpenAI Responses API con tu clave real.</span>
        <button className="button" disabled={loading}>{loading ? 'Generando...' : 'Probar respuesta'}</button>
      </div>
      {result ? <pre>{result}</pre> : null}
    </form>
  )
}
