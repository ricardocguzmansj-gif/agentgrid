'use client'

import { useState } from 'react'

const empty = {
  name: '',
  slug: '',
  industry: 'general',
  ownerEmail: '',
  brandPrimary: '#58a6ff',
  brandSecondary: '#07111f',
  supportEmail: ''
}

export function AdminCompanyForm() {
  const [form, setForm] = useState(empty)
  const [status, setStatus] = useState<string>('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setStatus('')
    try {
      const res = await fetch('/api/admin/companies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'No se pudo crear la empresa')
      setStatus(`Empresa creada: ${data.company.name}`)
      setForm(empty)
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={submit} className="card">
      <div className="grid grid-2">
        <label>Nombre<input value={form.name} onChange={(e)=>setForm({...form, name: e.target.value})} required /></label>
        <label>Slug<input value={form.slug} onChange={(e)=>setForm({...form, slug: e.target.value})} required /></label>
        <label>Industria
          <select value={form.industry} onChange={(e)=>setForm({...form, industry: e.target.value})}>
            <option value="general">General</option>
            <option value="ecommerce">Ecommerce</option>
            <option value="clinic">Clínica</option>
            <option value="real_estate">Inmobiliaria</option>
            <option value="education">Educación</option>
          </select>
        </label>
        <label>Email del owner<input type="email" value={form.ownerEmail} onChange={(e)=>setForm({...form, ownerEmail: e.target.value})} required /></label>
        <label>Color principal<input value={form.brandPrimary} onChange={(e)=>setForm({...form, brandPrimary: e.target.value})} /></label>
        <label>Color secundario<input value={form.brandSecondary} onChange={(e)=>setForm({...form, brandSecondary: e.target.value})} /></label>
        <label className="span-2">Email soporte<input type="email" value={form.supportEmail} onChange={(e)=>setForm({...form, supportEmail: e.target.value})} /></label>
      </div>
      <div className="row between center">
        <span className="small muted">Crea empresa, membership owner y agente inicial.</span>
        <button className="button" disabled={loading}>{loading ? 'Creando...' : 'Crear empresa'}</button>
      </div>
      {status ? <p className="small">{status}</p> : null}
    </form>
  )
}
