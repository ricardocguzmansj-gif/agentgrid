'use client'

import { useState } from 'react'

export function AgentForm({ companyId, companyName }: { companyId: string; companyName: string }) {
  const [name, setName] = useState(`${companyName} Sales Agent`)
  const [niche, setNiche] = useState('general')
  const [systemPrompt, setSystemPrompt] = useState(`You are the sales agent for ${companyName}.`) 
  const [status, setStatus] = useState('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('Guardando...')
    const res = await fetch('/api/company/agents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyId, name, niche, systemPrompt })
    })
    const data = await res.json()
    setStatus(res.ok ? `Agente creado: ${data.agent.name}` : data.error || 'Error')
  }

  return (
    <form onSubmit={submit} className="card">
      <h3>Nuevo agente</h3>
      <div className="grid grid-2">
        <label>Nombre<input value={name} onChange={(e)=>setName(e.target.value)} required /></label>
        <label>Nicho
          <select value={niche} onChange={(e)=>setNiche(e.target.value)}>
            <option value="general">General</option>
            <option value="ecommerce">Ecommerce</option>
            <option value="clinic">Clínica</option>
            <option value="real_estate">Inmobiliaria</option>
            <option value="education">Educación</option>
          </select>
        </label>
        <label className="span-2">Prompt del sistema<textarea rows={6} value={systemPrompt} onChange={(e)=>setSystemPrompt(e.target.value)} /></label>
      </div>
      <div className="row between center">
        <span className="small muted">Podés usarlo para WhatsApp, demo comercial o automatizaciones.</span>
        <button className="button">Guardar agente</button>
      </div>
      {status ? <p className="small">{status}</p> : null}
    </form>
  )
}
