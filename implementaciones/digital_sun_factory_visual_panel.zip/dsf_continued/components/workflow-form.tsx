'use client'

import { useState } from 'react'

export function WorkflowForm({ companyId }: { companyId: string }) {
  const [name, setName] = useState('Follow-up comercial')
  const [channelType, setChannelType] = useState('whatsapp')
  const [promptTemplate, setPromptTemplate] = useState('Escribí un seguimiento comercial cálido para un lead que pidió una demo.')
  const [cronSchedule, setCronSchedule] = useState('*/30 * * * *')
  const [targetContact, setTargetContact] = useState('5492640000000')
  const [status, setStatus] = useState('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('Guardando...')
    const res = await fetch('/api/company/workflows', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyId, name, channelType, promptTemplate, cronSchedule, targetContact })
    })
    const data = await res.json()
    setStatus(res.ok ? `Workflow creado: ${data.workflow.name}` : data.error || 'Error')
  }

  return (
    <form onSubmit={submit} className="card">
      <h3>Nueva automatización</h3>
      <div className="grid grid-2">
        <label>Nombre<input value={name} onChange={(e)=>setName(e.target.value)} required /></label>
        <label>Canal
          <select value={channelType} onChange={(e)=>setChannelType(e.target.value)}>
            <option value="whatsapp">WhatsApp</option>
            <option value="email">Email</option>
          </select>
        </label>
        <label className="span-2">Prompt plantilla<textarea rows={5} value={promptTemplate} onChange={(e)=>setPromptTemplate(e.target.value)} /></label>
        <label>Cron<input value={cronSchedule} onChange={(e)=>setCronSchedule(e.target.value)} /></label>
        <label>Contacto destino<input value={targetContact} onChange={(e)=>setTargetContact(e.target.value)} /></label>
      </div>
      <div className="row between center">
        <span className="small muted">Listo para dispararse desde Cloudflare Cron.</span>
        <button className="button">Guardar workflow</button>
      </div>
      {status ? <p className="small">{status}</p> : null}
    </form>
  )
}
