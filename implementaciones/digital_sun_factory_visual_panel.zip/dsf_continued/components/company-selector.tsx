'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import type { Company } from '@/lib/types'

export function CompanySelector({ companies, currentId, path }: { companies: Company[]; currentId?: string; path: string }) {
  const router = useRouter()
  const search = useSearchParams()

  return (
    <label className="selector">
      <span>Empresa activa</span>
      <select
        value={currentId || companies[0]?.id || ''}
        onChange={(e) => {
          const params = new URLSearchParams(search.toString())
          params.set('companyId', e.target.value)
          router.push(`${path}?${params.toString()}`)
        }}
      >
        {companies.map((company) => (
          <option key={company.id} value={company.id}>{company.name}</option>
        ))}
      </select>
    </label>
  )
}
