import { getSupabaseAdmin } from './supabase'
import type { AiAgent, AutomationWorkflow, Company } from './types'

export interface CompanyOverview {
  company: Company
  agentsCount: number
  activeAgents: number
  workflowsCount: number
  messages24h: number
  whatsappConnected: boolean
  latestMessages: Array<{ id: string; direction: 'in' | 'out'; contact_handle: string; content: string; created_at: string }>
}

const demoCompany: Company = {
  id: 'demo-company',
  name: 'Demo Company',
  slug: 'demo-company',
  industry: 'general',
  brand_primary: '#58a6ff',
  brand_secondary: '#07111f',
  support_email: 'demo@example.com',
  created_at: new Date().toISOString()
}

export async function listCompanies(): Promise<Company[]> {
  try {
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('companies').select('*').order('created_at', { ascending: false })
    if (error) throw error
    return (data as Company[]) || []
  } catch {
    return [demoCompany]
  }
}

export async function getCompanyOverview(companyId?: string): Promise<CompanyOverview> {
  try {
    const supabase = getSupabaseAdmin()
    let companyQuery = supabase.from('companies').select('*').order('created_at', { ascending: false }).limit(1)
    if (companyId) companyQuery = supabase.from('companies').select('*').eq('id', companyId).limit(1)
    const { data: companies, error: companyError } = await companyQuery
    if (companyError) throw companyError
    const company = (companies?.[0] as Company | undefined) ?? demoCompany

    const [{ count: agentsCount }, { count: activeAgents }, { count: workflowsCount }, { count: messages24h }, { data: channels }, inbound, outbound] = await Promise.all([
      supabase.from('ai_agents').select('*', { count: 'exact', head: true }).eq('company_id', company.id),
      supabase.from('ai_agents').select('*', { count: 'exact', head: true }).eq('company_id', company.id).eq('is_active', true),
      supabase.from('automation_workflows').select('*', { count: 'exact', head: true }).eq('company_id', company.id),
      supabase.from('inbound_messages').select('*', { count: 'exact', head: true }).eq('company_id', company.id).gte('created_at', new Date(Date.now() - 24*60*60*1000).toISOString()),
      supabase.from('whatsapp_channels').select('id').eq('company_id', company.id).eq('is_active', true).limit(1),
      supabase.from('inbound_messages').select('id, contact_handle, content, created_at').eq('company_id', company.id).order('created_at', { ascending: false }).limit(5),
      supabase.from('outbound_messages').select('id, contact_handle, content, created_at').eq('company_id', company.id).order('created_at', { ascending: false }).limit(5),
    ])

    const latestMessages = [
      ...((inbound.data ?? []).map((m:any) => ({ ...m, direction: 'in' as const }))),
      ...((outbound.data ?? []).map((m:any) => ({ ...m, direction: 'out' as const })))
    ].sort((a,b) => +new Date(b.created_at) - +new Date(a.created_at)).slice(0,8)

    return {
      company,
      agentsCount: agentsCount ?? 0,
      activeAgents: activeAgents ?? 0,
      workflowsCount: workflowsCount ?? 0,
      messages24h: messages24h ?? 0,
      whatsappConnected: (channels?.length ?? 0) > 0,
      latestMessages
    }
  } catch {
    return {
      company: demoCompany,
      agentsCount: 2,
      activeAgents: 1,
      workflowsCount: 3,
      messages24h: 14,
      whatsappConnected: false,
      latestMessages: [
        { id: '1', direction: 'in', contact_handle: '+549264000000', content: 'Hola, quiero una demo.', created_at: new Date().toISOString() },
        { id: '2', direction: 'out', contact_handle: '+549264000000', content: 'Perfecto, te ayudo a coordinarla.', created_at: new Date().toISOString() },
      ]
    }
  }
}

export async function listAgents(companyId: string): Promise<AiAgent[]> {
  try {
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('ai_agents').select('*').eq('company_id', companyId).order('created_at', { ascending: false })
    if (error) throw error
    return (data as AiAgent[]) || []
  } catch {
    return []
  }
}

export async function listWorkflows(companyId: string): Promise<AutomationWorkflow[]> {
  try {
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase.from('automation_workflows').select('*').eq('company_id', companyId).order('created_at', { ascending: false })
    if (error) throw error
    return (data as AutomationWorkflow[]) || []
  } catch {
    return []
  }
}
