import Link from 'next/link';
import { LeadForm } from '@/components/lead-form';
import { SectionTitle } from '@/components/section-title';
import { products } from '@/lib/content';

const benefits = [
  'Landing premium para vender SaaS y agentes de IA.',
  'Captura de leads con Supabase y validación Turnstile.',
  'Automatización de seguimiento comercial lista para cron.',
  'Sistema de afiliados con tracking de referidos.',
  'Stack optimizado para deploy en Cloudflare con Node.',
];

export default function HomePage() {
  return (
    <main>
      <section className="container-shell grid gap-12 py-20 lg:grid-cols-[1.2fr_0.8fr] lg:py-28">
        <div className="space-y-8">
          <div className="inline-flex rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm text-cyan-200">
            Digital Sun SaaS Factory · Node + Supabase + Cloudflare
          </div>
          <div className="space-y-5">
            <h1 className="max-w-4xl text-5xl font-semibold tracking-tight sm:text-6xl lg:text-7xl">
              Creá un sistema comercial completo para vender IA a empresas.
            </h1>
            <p className="max-w-2xl text-lg text-white/70 sm:text-xl">
              Landing ultra profesional, video de venta, automatización de leads, afiliados y estrategia para 1.000 clientes en una sola implementación lista para deploy.
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link className="button-primary" href="#demo-form">Solicitar demo gratis</Link>
            <Link className="button-secondary" href="/demo">Ver demo comercial</Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {benefits.map((benefit) => (
              <div key={benefit} className="card p-5 text-sm text-white/80">
                {benefit}
              </div>
            ))}
          </div>
        </div>
        <div className="card p-6 shadow-glow">
          <div className="mb-5 flex items-center justify-between text-sm text-white/60">
            <span>Máquina de ventas SaaS</span>
            <span>Deploy Cloudflare</span>
          </div>
          <div className="space-y-4">
            <div className="rounded-3xl border border-white/10 bg-black/20 p-5">
              <p className="text-sm text-cyan-300">Pipeline</p>
              <p className="mt-2 text-2xl font-semibold">Landing → Lead → Secuencia → Demo → Venta</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
                <p className="text-sm text-white/60">MRR target</p>
                <p className="mt-2 text-3xl font-semibold">1.000 clientes</p>
              </div>
              <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
                <p className="text-sm text-white/60">Canales</p>
                <p className="mt-2 text-3xl font-semibold">Inbound + afiliados</p>
              </div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-violet-500/20 to-cyan-500/20 p-5 text-sm text-white/80">
              Diseñado para vender Digital Sun, AgentGrid, marketplaces, turnos y soluciones de automatización inteligente.
            </div>
          </div>
        </div>
      </section>

      <section id="productos" className="container-shell py-16">
        <SectionTitle
          eyebrow="Ecosistema"
          title="Los productos que alimentan el funnel"
          text="La landing presenta tu ecosistema real y transforma visitas en oportunidades de negocio listas para cierre."
        />
        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {products.map((product) => (
            <a key={product.name} href={product.url} target="_blank" rel="noreferrer" className="card p-6 transition hover:-translate-y-1 hover:border-cyan-300/30">
              <h3 className="text-2xl font-semibold">{product.name}</h3>
              <p className="mt-3 text-white/70">{product.description}</p>
              <span className="mt-6 inline-flex text-sm text-cyan-300">Abrir sitio ↗</span>
            </a>
          ))}
        </div>
      </section>

      <section className="container-shell py-16">
        <div className="grid gap-10 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="space-y-6">
            <SectionTitle
              eyebrow="Cómo se vende"
              title="Un embudo que convierte interés en demos"
              text="La base está pensada para campañas, tráfico orgánico, afiliados y seguimiento comercial automatizado."
            />
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                '1. Tráfico a landing con CTA directa.',
                '2. Captura de lead con objetivo comercial.',
                '3. Secuencia automática y aviso a ventas.',
                '4. Demo guiada con guion y escenas.',
                '5. Oferta con planes y link de afiliado.',
                '6. Escalado por contenido, ads y partners.',
              ].map((item) => (
                <div key={item} className="card p-5 text-white/80">{item}</div>
              ))}
            </div>
          </div>
          <div id="demo-form">
            <LeadForm />
          </div>
        </div>
      </section>

      <section className="container-shell py-16">
        <div className="card grid gap-8 p-8 lg:grid-cols-3 lg:p-10">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">CTA final</p>
            <h3 className="mt-3 text-3xl font-semibold">Probá el sistema completo y usalo como demo comercial.</h3>
          </div>
          <p className="text-white/70 lg:col-span-1">
            Llevá este starter a tu hosting, conectalo a Supabase, activá el cron de Cloudflare y empezá a captar leads con automatización real.
          </p>
          <div className="flex flex-wrap gap-4 lg:justify-end">
            <Link className="button-primary" href="/demo">Ver demo</Link>
            <Link className="button-secondary" href="/afiliados">Activar afiliados</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
