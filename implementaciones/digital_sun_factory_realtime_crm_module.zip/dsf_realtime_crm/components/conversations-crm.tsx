'use client'

import { useEffect, useMemo, useState } from 'react'
import { getSupabaseBrowser } from '@/lib/supabase-browser'

type Conversation = {
  id: string
  contact_name: string | null
  contact_phone: string | null
  channel: string
  status: string
  last_message_at: string | null
}

type Message = {
  id: string
  conversation_id: string
  direction: 'inbound' | 'outbound'
  content: string
  created_at: string
}

export default function ConversationsCRM() {
  const supabase = useMemo(() => getSupabaseBrowser(), [])
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selected, setSelected] = useState<string>('')
  const [messages, setMessages] = useState<Message[]>([])
  const [draft, setDraft] = useState('')
  const [loading, setLoading] = useState(true)

  async function loadConversations() {
    const res = await fetch('/api/company/conversations', { cache: 'no-store' })
    const json = await res.json()
    setConversations(json.conversations ?? [])
    if (!selected && json.conversations?.[0]?.id) setSelected(json.conversations[0].id)
    setLoading(false)
  }

  async function loadMessages(conversationId: string) {
    const res = await fetch(`/api/company/conversations?conversationId=${conversationId}`, { cache: 'no-store' })
    const json = await res.json()
    setMessages(json.messages ?? [])
  }

  async function sendMessage() {
    if (!selected || !draft.trim()) return
    const content = draft
    setDraft('')
    await fetch('/api/company/messages/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversationId: selected, content }),
    })
    await loadMessages(selected)
    await loadConversations()
  }

  useEffect(() => {
    loadConversations()
  }, [])

  useEffect(() => {
    if (selected) loadMessages(selected)
  }, [selected])

  useEffect(() => {
    const channel = supabase
      .channel('crm-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, (payload) => {
        if ((payload.new as Message | undefined)?.conversation_id === selected || (payload.old as Message | undefined)?.conversation_id === selected) {
          loadMessages(selected)
        }
        loadConversations()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, selected])

  const selectedConversation = conversations.find((c) => c.id === selected)

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-[360px_1fr]">
      <aside className="rounded-2xl border border-zinc-800 bg-zinc-950">
        <div className="border-b border-zinc-800 p-4">
          <h2 className="text-lg font-semibold text-white">Conversaciones</h2>
          <p className="text-sm text-zinc-400">Bandeja en tiempo real</p>
        </div>
        <div className="max-h-[70vh] overflow-y-auto">
          {loading ? (
            <div className="p-4 text-sm text-zinc-400">Cargando…</div>
          ) : conversations.length === 0 ? (
            <div className="p-4 text-sm text-zinc-400">No hay conversaciones todavía.</div>
          ) : (
            conversations.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelected(c.id)}
                className={`w-full border-b border-zinc-900 px-4 py-3 text-left transition ${selected === c.id ? 'bg-zinc-900' : 'hover:bg-zinc-900/60'}`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium text-white">{c.contact_name || c.contact_phone || 'Sin nombre'}</div>
                    <div className="text-xs text-zinc-400">{c.contact_phone || 'sin teléfono'} · {c.channel}</div>
                  </div>
                  <span className="rounded-full border border-zinc-700 px-2 py-1 text-[10px] uppercase tracking-wide text-zinc-300">{c.status}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </aside>

      <section className="flex min-h-[70vh] flex-col rounded-2xl border border-zinc-800 bg-zinc-950">
        <div className="border-b border-zinc-800 p-4">
          <h2 className="text-lg font-semibold text-white">{selectedConversation?.contact_name || selectedConversation?.contact_phone || 'Seleccioná una conversación'}</h2>
          <p className="text-sm text-zinc-400">Respuesta manual y seguimiento comercial</p>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.length === 0 ? (
            <div className="text-sm text-zinc-500">No hay mensajes para mostrar.</div>
          ) : (
            messages.map((m) => (
              <div key={m.id} className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${m.direction === 'outbound' ? 'ml-auto bg-emerald-600 text-white' : 'bg-zinc-900 text-zinc-100'}`}>
                <div>{m.content}</div>
                <div className={`mt-2 text-[11px] ${m.direction === 'outbound' ? 'text-emerald-100/80' : 'text-zinc-500'}`}>{new Date(m.created_at).toLocaleString()}</div>
              </div>
            ))
          )}
        </div>

        <div className="border-t border-zinc-800 p-4">
          <div className="flex gap-3">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={3}
              placeholder="Escribí una respuesta manual…"
              className="min-h-[90px] flex-1 rounded-xl border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white outline-none"
            />
            <button
              onClick={sendMessage}
              className="rounded-xl bg-white px-5 py-3 text-sm font-semibold text-black"
            >
              Enviar
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
