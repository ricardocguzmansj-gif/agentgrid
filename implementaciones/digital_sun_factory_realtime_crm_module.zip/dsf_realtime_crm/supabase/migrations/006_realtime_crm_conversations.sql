create extension if not exists pgcrypto;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null,
  contact_name text,
  contact_phone text,
  channel text not null default 'whatsapp',
  status text not null default 'open',
  last_message_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  direction text not null check (direction in ('inbound','outbound')),
  content text not null,
  provider_message_id text,
  sender_name text,
  created_at timestamptz not null default now()
);

create index if not exists idx_conversations_company_last_message on public.conversations(company_id, last_message_at desc);
create index if not exists idx_messages_conversation_created on public.messages(conversation_id, created_at asc);
create index if not exists idx_messages_company_created on public.messages(company_id, created_at desc);

alter table public.conversations enable row level security;
alter table public.messages enable row level security;

-- Ajustá esta función a tu esquema real si ya la tenés
create or replace function public.current_company_ids()
returns setof uuid
language sql
stable
as $$
  select company_id
  from public.company_memberships
  where user_id = auth.uid()
$$;

create policy if not exists "members can read company conversations"
on public.conversations
for select
using (company_id in (select public.current_company_ids()));

create policy if not exists "members can insert company conversations"
on public.conversations
for insert
with check (company_id in (select public.current_company_ids()));

create policy if not exists "members can update company conversations"
on public.conversations
for update
using (company_id in (select public.current_company_ids()))
with check (company_id in (select public.current_company_ids()));

create policy if not exists "members can read company messages"
on public.messages
for select
using (company_id in (select public.current_company_ids()));

create policy if not exists "members can insert company messages"
on public.messages
for insert
with check (company_id in (select public.current_company_ids()));

alter publication supabase_realtime add table public.conversations;
alter publication supabase_realtime add table public.messages;
