import { headers } from 'next/headers'

export async function getCurrentCompanyId() {
  const h = await headers()
  return h.get('x-company-id') || ''
}
