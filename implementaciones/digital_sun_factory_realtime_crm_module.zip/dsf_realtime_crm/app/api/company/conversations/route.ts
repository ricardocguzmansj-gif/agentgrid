import { NextRequest, NextResponse } from 'next/server'
import { getSupabaseServer } from '@/lib/supabase-server'
import { getCurrentCompanyId } from '@/lib/company'

export async function GET(req: NextRequest) {
  const companyId = await getCurrentCompanyId()
  if (!companyId) {
    return NextResponse.json({ error: 'company_not_selected' }, { status: 400 })
  }

  const conversationId = req.nextUrl.searchParams.get('conversationId')
  const supabase = getSupabaseServer()

  if (conversationId) {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('company_id', companyId)
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ messages: data ?? [] })
  }

  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('company_id', companyId)
    .order('last_message_at', { ascending: false, nullsFirst: false })
    .limit(100)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ conversations: data ?? [] })
}
