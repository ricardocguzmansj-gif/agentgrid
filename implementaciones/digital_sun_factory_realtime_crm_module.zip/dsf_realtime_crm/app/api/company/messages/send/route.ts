import { NextRequest, NextResponse } from 'next/server'
import { getSupabaseServer } from '@/lib/supabase-server'
import { getCurrentCompanyId } from '@/lib/company'

export async function POST(req: NextRequest) {
  const companyId = await getCurrentCompanyId()
  if (!companyId) {
    return NextResponse.json({ error: 'company_not_selected' }, { status: 400 })
  }

  const body = await req.json()
  const { conversationId, content } = body as { conversationId?: string; content?: string }

  if (!conversationId || !content?.trim()) {
    return NextResponse.json({ error: 'missing_fields' }, { status: 400 })
  }

  const supabase = getSupabaseServer()
  const now = new Date().toISOString()

  const { error } = await supabase.from('messages').insert({
    company_id: companyId,
    conversation_id: conversationId,
    direction: 'outbound',
    content: content.trim(),
    created_at: now,
  })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  await supabase
    .from('conversations')
    .update({ last_message_at: now, updated_at: now })
    .eq('company_id', companyId)
    .eq('id', conversationId)

  // Hook listo para canal externo, por ejemplo WhatsApp.
  // Aquí podés invocar sendWhatsAppMessage(companyId, conversationId, content)

  return NextResponse.json({ ok: true })
}
