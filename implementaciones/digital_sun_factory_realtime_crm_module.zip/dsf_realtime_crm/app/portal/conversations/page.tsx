import ConversationsCRM from '@/components/conversations-crm'

export default function PortalConversationsPage() {
  return (
    <main className="min-h-screen bg-black p-6 text-white">
      <div className="mx-auto max-w-7xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold">CRM Conversacional</h1>
          <p className="mt-2 text-zinc-400">Bandeja en tiempo real para WhatsApp, seguimiento y respuesta manual.</p>
        </div>
        <ConversationsCRM />
      </div>
    </main>
  )
}
