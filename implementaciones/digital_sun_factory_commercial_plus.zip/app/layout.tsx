import './globals.css';
import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Digital Sun SaaS Factory',
  description: 'Landing, automatización de leads, afiliados y demo comercial listos para deploy con Node, Supabase y Cloudflare.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/80 backdrop-blur-xl">
          <div className="container-shell flex items-center justify-between py-4">
            <Link href="/" className="text-lg font-semibold tracking-tight">
              Digital Sun <span className="text-cyan-300">SaaS Factory</span>
            </Link>
            <nav className="hidden gap-6 text-sm text-white/80 md:flex">
              <Link href="/#productos">Productos</Link>
              <Link href="/demo">Demo</Link>
              <Link href="/afiliados">Afiliados</Link>
              <Link href="/pricing">Pricing</Link>
              <Link href="/estrategia">1.000 clientes</Link>
              <Link href="/login">Login</Link>
            </nav>
          </div>
        </header>
        {children}
      </body>
    </html>
  );
}
